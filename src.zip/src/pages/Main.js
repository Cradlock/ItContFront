import React from "react";

class Main extends React.Component {
  render() {
    return (
      <main>
        <h1 className="main_title">Проект для академи IT-RUN (вродебы)</h1>
      </main>
    );
  }
}
export default Main;
